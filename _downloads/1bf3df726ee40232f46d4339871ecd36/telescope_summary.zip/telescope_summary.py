"""
Telescope Summary
=================

An example showing the constituants and, therefore, photon paths of all 
FOXSI-4 telescopes.
"""

import response_tools.telescope_parts as telescope_parts
import numpy as np
import matplotlib as mpl

def behemoth_plot():
    blank_sentinel = "BLANK"
    mosaic = [
        ["p0_prefilter",    "p1_prefilter",     "BLANK",        "BLANK",        "BLANK",        "BLANK",        "BLANK",        "r0_annotate"],
        ["p0_collimator",   "p1_collimator",    "p2_blanket",   "p3_blanket",   "p4_blanket",   "p5_blanket",   "p6_blanket",   "r1_annotate"],
        ["p0_optics",       "p1_optics",        "p2_optics",    "p3_optics",    "p4_optics",    "p5_optics",    "p6_optics",    "r2_annotate"],
        ["BLANK",           "BLANK",            "BLANK",        "p3_attenuator","BLANK",        "p5_attenuator","BLANK",        "r3_annotate"],
        ["p0_obf",          "p1_obf",           "p2_filter",    "p3_mylar",     "p4_filter",    "p5_mylar",     "p6_mylar",     "r4_annotate"],
        ["p0_detector",     "p1_detector",      "p2_detector",  "p3_detector",  "p4_detector",  "p5_detector",  "p6_detector",  "r5_annotate"],
        ["p0_annotate",     "p1_annotate",      "p2_annotate",  "p3_annotate",  "p4_annotate",  "p5_annotate",  "p6_annotate",  "corner"],
    ]

    fig, ax = mpl.pyplot.subplot_mosaic(mosaic, figsize=(12,8), empty_sentinel=blank_sentinel, width_ratios=[2, 2, 2, 2, 2, 2, 2, 1], height_ratios=[2, 2, 2, 2, 2, 2, 1])




    mpl.pyplot.show()
    
behemoth_plot()
